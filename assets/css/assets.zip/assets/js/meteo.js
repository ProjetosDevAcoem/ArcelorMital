document.addEventListener('DOMContentLoaded', function () {
    const stationButtons = document.querySelectorAll('.station-btn');

    stationButtons.forEach(button => {
        button.addEventListener('click', function () {
            // Remove active class from all buttons
            stationButtons.forEach(btn => btn.classList.remove('active'));

            // Add active class to clicked button
            this.classList.add('active');

            // Get station ID
            const stationId = this.dataset.station;

            // Animate values changing
            updateStationData(stationId);
        });
    });
});

function updateStationData(stationId) {
    // Add animation class to values
    document.querySelectorAll('.meteo-value').forEach(el => {
        el.classList.add('animate__animated', 'animate__fadeIn');

        // Remove animation class after animation ends
        el.addEventListener('animationend', () => {
            el.classList.remove('animate__animated', 'animate__fadeIn');
        });
    });

    // Fetch and update data based on selected station
    // This is where you'll add your actual data fetching logic
    // For now, we'll just simulate with random values
    setTimeout(() => {
        document.querySelector('#temperature .value').textContent =
            Math.floor(Math.random() * 15 + 20); // 20-35°C
        document.querySelector('#humidity .value').textContent =
            Math.floor(Math.random() * 30 + 50); // 50-80%
        document.querySelector('#wind-speed .value').textContent =
            Math.floor(Math.random() * 20 + 5); // 5-25 km/h
        document.querySelector('#pressure .value').textContent =
            Math.floor(Math.random() * 30 + 1000); // 1000-1030 hPa

        // Update charts
        updateCharts(stationId);
    }, 300);
}

function updateCharts(stationId) {
    // Add your chart updating logic here
    // This will depend on your data structure and Plotly.js implementation
}