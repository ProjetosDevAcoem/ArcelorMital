function gerarGraficoPM10() {
    fetch('grafico.php')  
    .then(response => {
        if (!response.ok) {
            throw new Error(`Erro HTTP! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(dados => {
        const agora = new Date();
        const HorasAtras24 = new Date(agora - 24 * 60 * 60 * 1000); // 24 horas atrás
        const inicioDoDia = new Date();
        inicioDoDia.setHours(0, 0, 0, 0);

        const dadosUltimas24h = dados.filter(item => {
            const dataItem = new Date(item.DataHora);
            return dataItem >= HorasAtras24;
        });

        const labels = dadosUltimas24h.map(item => {
            const date = new Date(item.DataHora);
            const hora = date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

            return date >= inicioDoDia 
                ? hora 
                : date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'long' }) + ' ' + hora;
        });

        const pm10 = dadosUltimas24h.map(item => item.PM10AVG1H);

        // Criar o gráfico com Plotly
        const trace = {
            x: labels,
            y: pm10,
            type: 'bar',
            name: 'PM2.5'
        };

        const layout = {
            title: 'Monitoramento de PM2.5',
            xaxis: { title: 'Hora de Coleta' },
            yaxis: { title: 'PM2.5' }
        };

        Plotly.newPlot('chart', [trace], layout);
    })
    .catch(error => console.error('Erro ao carregar os dados:', error));
}
