document.addEventListener('DOMContentLoaded', function() {
    carregarEstacoes();
    // Não chame gerarGraficoAQI aqui; será chamado ao selecionar a estação e data
});

// Função para carregar as estações
function carregarEstacoes() {
    fetch('file.php') // Chama o PHP que retorna as estações
        .then(response => response.json())
        .then(estacoes => {
            const select = document.getElementById('tag');
            select.innerHTML = '<option value="">Selecione uma estação</option>';

            // Adiciona cada estação como opção no select
            estacoes.forEach(estacao => {
                const option = document.createElement('option');
                option.value = estacao.SerialNumber;
                option.textContent = estacao.Tag;
                select.appendChild(option);
            });

            // Após carregar as estações, ouça o evento de mudança de estação e data
            select.addEventListener('change', gerarGraficoAQI);
            document.getElementById('startDate').addEventListener('change', gerarGraficoAQI);
            document.getElementById('endDate').addEventListener('change', gerarGraficoAQI);
        })
        .catch(error => console.error('Erro ao carregar estações:', error));
}

function gerarGraficoAQI() {
    const nomeEstacao = document.getElementById('tag').value;
    const startDateInput = document.getElementById('startDate').value;
    const endDateInput = document.getElementById('endDate').value;

    // Verifica se uma estação foi selecionada
    if (!nomeEstacao) {
        console.log("Selecione uma estação para visualizar os dados.");
        return;
    }

    // Verifica se as datas estão selecionadas
    if (!startDateInput || !endDateInput) {
        console.log("Por favor, selecione um intervalo de datas.");
        return;
    }

    // Converter startDate e endDate para timestamps (milissegundos ou segundos)
    const startDateTimestamp = new Date(startDateInput).getTime() / 1000; // Convertendo para segundos
    const endDateTimestamp = new Date(endDateInput).getTime() / 1000; // Convertendo para segundos

    console.log(`Start Date: ${startDateInput} (Timestamp: ${startDateTimestamp})`);
    console.log(`End Date: ${endDateInput} (Timestamp: ${endDateTimestamp})`);

    let url = `PoluentesDados.php?tag=${encodeURIComponent(nomeEstacao)}`;
    if (startDateInput) url += `&startDate=${encodeURIComponent(startDateInput)}`;
    if (endDateInput) url += `&endDate=${encodeURIComponent(endDateInput)}`;

    fetch(url)
        .then(response => response.json())
        .then(dados => {
            console.log("Resposta do servidor:", dados); // Debug

            // Verifica a estrutura dos dados para garantir que estamos acessando a estação corretamente
            if (!dados || !dados[nomeEstacao]) {
                console.log(`Nenhum dado encontrado para a estação ${nomeEstacao}.`);
                Plotly.newPlot('chart', [], { title: "Nenhum dado disponível" });
                return;
            }

            // Dados da estação específica
            let dadosEstacao = dados[nomeEstacao];

            // Filtrar dados nulos ou vazios
            dadosEstacao = dadosEstacao.filter(item => item.iqa_final !== null && item.iqa_final !== undefined);

            // Filtrar os dados pelo intervalo de datas
            dadosEstacao = dadosEstacao.filter(item => {
                const itemTimestamp = Number(item.TimeStamp); // Timestamp em segundos ou milissegundos
                console.log(`Item Timestamp: ${itemTimestamp}`); // Log para verificar o formato
                return itemTimestamp >= startDateTimestamp && itemTimestamp <= endDateTimestamp;
            });

            // Verificar se os dados filtrados possuem conteúdo
            if (dadosEstacao.length === 0) {
                console.log("Nenhum dado válido encontrado para os filtros selecionados.");
                Plotly.newPlot('chart', [], { title: "Nenhum dado disponível" });
                return;
            }

            // Extrair AQI e TimeStamp
            const aqi = dadosEstacao.map(item => item.iqa_final);
            const time = dadosEstacao.map(item => {
                const date = new Date(Number(item.TimeStamp) * 1000); // Convertendo para formato legível
                return date.toLocaleString('pt-BR');
            });

            // Criar o gráfico
            const trace = {
                x: time,
                y: aqi,
                type: 'bar',
                name: 'AQI'
            };

            const layout = {
                title: `Monitoramento de AQI - ${nomeEstacao}`,
                xaxis: { title: 'Hora de Coleta' },
                yaxis: { title: 'AQI' }
            };

            Plotly.newPlot('chart', [trace], layout);
        })
        .catch(error => console.error('Erro ao carregar os dados:', error));
}
